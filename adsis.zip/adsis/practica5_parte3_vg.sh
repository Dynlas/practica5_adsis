#!/bin/bash

# Script añade al grupo de volumen indicado disco.

#Comprobar parámetros
if [ $# -lt 2 ]; then
    echo "Uso: $0 <nombre_vg> <nombre_part_1> ..." 
    exit 1
fi

# Permisos de administrador
if [ $EUID -ne 0 ]; then
    echo "Se requieren permisos de administrador"
    exit 1
fi

#Nombre del volumen lógico
vg="$1"
shift 


# Comprobamos 
if ! vgdisplay "$vg" > /dev/null 2>&1; then
    echo "El grupo de volúmenes \"$vg\" no se ha encontrado"
    exit 1
fi

# Ahora recorremos los parámetros para ir añadiéndolos
for part in "$@"; do
    # Se revisa que exista la partición
    if ! lsblk | grep -q "${part}"; then
        echo "No se ha encontrado la partición \"$part\""
        continue
    fi

    # Se revisa si la partición está montada
    if mount | grep -q "$part"; then
        echo "La partición \"$part\" está montada, por lo que la desmontamos"
        # La desmontamos en caso de estar montada
        umount "$part"
        if [ $? -ne 0 ]; then
            echo "Error al desmontar la partición \"$part\""
            continue
        fi
    fi

    # Extender el grupo de volúmenes con la nueva partición
    vgextend "$vg" "$part"
    if [ $? -eq 0 ]; then
        echo "La partición \"$part\" se ha añadido al grupo de volúmenes \"$vg\" correctamente"
    else
        echo "Error al añadir la partición \"$part\" al grupo de volúmenes \"$vg\""
    fi
done

