#!/bin/bash

# Verificar que se tienen permisos de administrador
if [ "$EUID" -ne 0 ]; then
    echo "Se requieren permisos de administrador"
    exit 1
fi

# Leer la entrada estándar
echo "Formato: nombreVG,nombreLV,size,tipoFS,dirMontaje"
echo -n "-> "
OldIFS=$IFS
IFS=,
read vg lv size fs dirM
IFS=$OldIFS

# Comprobar que ninguno de los campos sea vacío
if [ -z "$vg" ] || [ -z "$lv" ] || [ -z "$size" ] || [ -z "$fs" ] || [ -z "$dirM" ]; then
    echo "Alguno de los campos introducidos es igual a la cadena vacía"
    exit 1
fi

# Verificar que el grupo de volúmenes exista
if ! vgdisplay "$vg" > /dev/null 2>&1; then
    echo "El grupo de volúmenes \"$vg\" no se ha encontrado"
    exit 1
fi

# Comprobar que el tamaño tenga un formato correcto
if ! echo "$size" | grep -q '^[0-9]\+\(B\|K\|M\|G\)$'; then
    echo "Tamaño introducido incorrectamente. Formato: [0-9]+(B|K|M|G)"
    exit 1
fi

# Comprobar que el sistema de ficheros sea válido
if ! grep -qw "$fs" /proc/filesystems; then
    echo "$fs no es un sistema de ficheros soportado"
    exit 1
fi

# Comprobar que el punto de montaje exista
if [ ! -d "$dirM" ]; then
    echo "El directorio $dirM no existe o no es accesible"
    exit 1
fi

# Crear o expandir el volumen lógico
lv_path="/dev/$vg/$lv"
if ! lvdisplay "$lv_path" > /dev/null 2>&1; then
    echo "Creando $lv..."
    lvcreate -L "$size" --name "$lv" "$vg"
    mkfs -t "$fs" "$lv_path"
    mount -t "$fs" "$lv_path" "$dirM"
    echo "$(blkid "$lv_path" | awk '{print $2}' | tr -d '\"') $dirM $fs defaults 0 0" | tee -a /etc/fstab
else
    echo "Expandiendo $lv..."
    umount "$lv_path"
    lvextend -L +"$size" "$lv_path"
    if [ "$fs" = "ext2" ] || [ "$fs" = "ext3" ] || [ "$fs" = "ext4" ]; then
        resize2fs "$lv_path"
    else
        echo "Sistema de archivos $fs no soporta redimensionamiento automático. Por favor, redimensione manualmente."
    fi
    mount -t "$fs" "$lv_path" "$dirM"
fi

