#!/bin/bash

# Verificar si se proporciona la dirección IP
if [ $# -ne 1 ]; then
    echo "Uso: $0 <direccion_ip>"
    exit 1
fi

REMOTE_IP="$1"

# Función para ejecutar comandos remotos y manejar errores
run_remote_command() {
    local COMMAND="$1"
    ssh "$REMOTE_IP" "$COMMAND"
    if [ $? -ne 0 ]; then
        echo "Error al ejecutar el comando: $COMMAND"
        exit 1
    fi
}

# Comprobando los discos duros disponibles y sus tamaños en bloques
echo "Discos duros disponibles y sus tamaños en bloques:"
run_remote_command "sfdisk -s"

# Comprobando las particiones y sus tamaños
echo -e "\nParticiones y sus tamaños:"
run_remote_command "sfdisk -l"

# Información de montaje de sistemas de archivos (salvo tmpfs)
echo -e "\nInformación de montaje de sistemas de archivos (salvo tmpfs):"
run_remote_command "df -hT | grep -v tmpfs"

# Fin del script
echo -e "\nComprobación completada para la IP: $REMOTE_IP"

